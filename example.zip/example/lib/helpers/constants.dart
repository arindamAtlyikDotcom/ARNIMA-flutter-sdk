class Constants {
  Constants._();
  static const double padding = 20;
}
