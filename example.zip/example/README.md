# AriesFlutterMobileAgent_example

Demonstrates how to use the AriesFlutterMobileAgent plugin.

## Getting Started

Install the packages and run the application

