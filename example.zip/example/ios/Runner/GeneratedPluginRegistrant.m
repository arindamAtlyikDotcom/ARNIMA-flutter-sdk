//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<AriesFlutterMobileAgent/AriesFlutterMobileAgentPlugin.h>)
#import <AriesFlutterMobileAgent/AriesFlutterMobileAgentPlugin.h>
#else
@import AriesFlutterMobileAgent;
#endif

#if __has_include(<barcode_scan2/BarcodeScanPlugin.h>)
#import <barcode_scan2/BarcodeScanPlugin.h>
#else
@import barcode_scan2;
#endif

#if __has_include(<path_provider/FLTPathProviderPlugin.h>)
#import <path_provider/FLTPathProviderPlugin.h>
#else
@import path_provider;
#endif

#if __has_include(<permission_handler/PermissionHandlerPlugin.h>)
#import <permission_handler/PermissionHandlerPlugin.h>
#else
@import permission_handler;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [AriesFlutterMobileAgentPlugin registerWithRegistrar:[registry registrarForPlugin:@"AriesFlutterMobileAgentPlugin"]];
  [BarcodeScanPlugin registerWithRegistrar:[registry registrarForPlugin:@"BarcodeScanPlugin"]];
  [FLTPathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTPathProviderPlugin"]];
  [PermissionHandlerPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionHandlerPlugin"]];
}

@end
